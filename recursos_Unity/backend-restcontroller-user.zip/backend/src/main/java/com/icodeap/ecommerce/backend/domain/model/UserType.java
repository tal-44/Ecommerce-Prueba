package com.icodeap.ecommerce.backend.domain.model;

public enum UserType {
    ADMIN, USER
}
