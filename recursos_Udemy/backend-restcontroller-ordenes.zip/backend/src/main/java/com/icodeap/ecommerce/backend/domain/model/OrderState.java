package com.icodeap.ecommerce.backend.domain.model;

public enum OrderState {
    CANCELLED, CONFIRMED
}
